# 4U02-Fabrication-of-Solar-Cells
Matlab code contain all calculations, figures, and tables for the lab report of the same name.

Matlab code contain all calculations, figures, and tables for the lab report of the same name. All the files are necessary to run the code, however only Solar_Cell_4U02_Lab.m and lab_4U02_resistance.m need to be executed. It is suggested to run sections of the script individually as each consecutive script will close the figures before it. This was done as too many figures pop up if everything is run at the same time.

Solar_Cell_4U02_Lab.m will perform all of the analysis on the final IV curves on all 4 quadrants of the solar cell. The raw data is also included in matlab format.

lab_4U02_resistance.m will analyse the contact resistance from the IV curves collected across various electrode spacing. The raw data for this is also included in matlab formate.
